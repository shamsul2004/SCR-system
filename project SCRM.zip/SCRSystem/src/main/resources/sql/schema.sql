CREATE TABLE Roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL
);

CREATE TABLE Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role_id INT,
    FOREIGN KEY (role_id) REFERENCES Roles(id)
);

CREATE TABLE Projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE ChangeRequests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    priority ENUM('Low', 'Medium', 'High') NOT NULL,
    due_date DATE,
    status ENUM('Pending', 'Approved', 'Rejected', 'In Development', 'Completed') NOT NULL,
    project_id INT,
    requester_id INT,
    FOREIGN KEY (project_id) REFERENCES Projects(id),
    FOREIGN KEY (requester_id) REFERENCES Users(id)
);

CREATE TABLE Teams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE TeamMembers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT,
    user_id INT,
    FOREIGN KEY (team_id) REFERENCES Teams(id),
    FOREIGN KEY (user_id) REFERENCES Users(id)
);

CREATE TABLE Timeline (
    id INT AUTO_INCREMENT PRIMARY KEY,
    change_request_id INT,
    stage ENUM('Request Raised', 'Approved', 'In Development', 'Completed', 'Submitted for Review'),
    start_date DATETIME,
    end_date DATETIME,
    comments TEXT,
    FOREIGN KEY (change_request_id) REFERENCES ChangeRequests(id)
);
