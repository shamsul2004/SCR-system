package com.scrsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SCRSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(SCRSystemApplication.class, args);
    }
}
