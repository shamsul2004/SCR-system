document.getElementById('changeRequestForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const priority = document.getElementById('priority').value;
    const dueDate = document.getElementById('dueDate').value;

    fetch('/api/changerequests', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            title,
            description,
            priority,
            dueDate
        }),
    })
    .then(response => response.json())
    .then(data => {
        alert('Change Request Submitted: ' + data.title);
        document.getElementById('changeRequestForm').reset();
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});
