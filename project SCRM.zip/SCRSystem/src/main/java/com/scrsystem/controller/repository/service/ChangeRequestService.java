package main.java.com.scrsystem.controller.repository.service;
import com.scrsystem.model.ChangeRequest;
import com.scrsystem.repository.ChangeRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChangeRequestService {

    @Autowired
    private ChangeRequestRepository changeRequestRepository;

    public ChangeRequest createChangeRequest(ChangeRequest changeRequest) {
        return changeRequestRepository.save(changeRequest);
    }

    public List<ChangeRequest> getAllChangeRequests() {
        return changeRequestRepository.findAll();
    }
}
